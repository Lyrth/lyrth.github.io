import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.file.Files;

public class Student extends Person {

    private int numModules = 0;
    private int numRepeatModules = 0;
    private double deposit = 0;

    static File studentsFile = new File("students.txt");

    public Student(int ID, String firstName, String lastName, Gender gender, String phoneNumber, String address){
        super(ID, firstName, lastName, gender, phoneNumber, address);
    }

    public static Student createAccount(int ID, String firstName, String lastName, Gender gender, String phoneNumber, String address){
        return new Student(ID, firstName, lastName, gender, phoneNumber, address);
    }

    public int getNumModules() {
        return numModules;
    }

    public void updateNumModules(int numModules) {
        this.numModules = numModules;
    }

    public int getNumRepeatModules() {
        return numRepeatModules;
    }

    public void updateNumRepeatModules(int numRepeatModules) {
        this.numRepeatModules = numRepeatModules;
    }

    public double getAmountPaid() {
        return deposit;
    }

    public void setDeposit(double deposit) {
        this.deposit = deposit;
    }

    public void addDeposit(double deposit) {
        this.deposit += deposit;
    }


    // Calculations

    public double computeRemainingBalance() {
        double toPay = (numModules * 525) + (numRepeatModules * 110);
        return toPay - deposit;
    }

    public double getFeeDeposit() {
        return getAmountPaid();  // is the same.
    }


    // Print/Format operations

    public String info(){
        return String.format(
            "ID: %s \n" +
                "Role: Student\n" +
                "Name: %s\n" +
                "Gender: %s\n" +
                "Phone Number: %s\n" +
                "Address: %s\n" +
                "Number of Modules (and Repeat) Enrolled: %d (%d)\n",
            getID(), getName(true), getGender(), getPhoneNumber(), getAddress(),
            getNumModules(), getNumRepeatModules()
        );
    }

    public String balanceInfo(){
        return String.format("Initial deposit: %.2f\n" +
                "Remaining Balance: Php %.2f\n",
            getFeeDeposit(), computeRemainingBalance());
    }

    public void printInfo(){
        System.out.print(info());
    }


    // Input operations

    public static Student createFromInput(){
        int ID, modules = 0, repeatModules = 0;
        double deposit;
        String firstName, lastName, phoneNumber, address;
        Gender gender;
        ID = getStudentIDInput();
        firstName = getLine("Enter first name: ");
        lastName = getLine("Enter last name: ");
        System.out.println("Genders: ");
        System.out.println("1 - Male");
        System.out.println("2 - Female");
        System.out.println("3 - Unspecified");
        int choice = getInt("Enter gender: ", 3);
        switch (choice){
            case 1:
                gender = Gender.Male;
                break;
            case 2:
                gender = Gender.Female;
                break;
            default:
                gender = Gender.Unspecified;
        }
        phoneNumber = getLine("Enter phone number: ");
        address = getLine("Enter address: ");

        modules = getInt("Enter number of modules enrolled <default 0> [0-6]: ",0,6);
        if (modules > 0 && modules < 5)
            repeatModules = getInt("Enter number of repeat modules enrolled <default 0> [0-2]: ",0,2);
        else if (modules > 0 && modules < 6)
            repeatModules = getInt("Enter number of repeat modules enrolled <default 0> [0-1]: ",0,2);
        else if (modules == 6)
            System.out.println("Cannot take repeat modules with 6 modules already.");
        else if (modules == 0)
            repeatModules = getInt("Enter number of repeat modules enrolled <default 0> [0-6]:");
        deposit = getDouble("Enter deposit in Php <default 0.00>: ");

        Student student = new Student(ID,firstName,lastName,gender,phoneNumber,address);
        student.updateNumModules(modules);
        student.updateNumRepeatModules(repeatModules);
        student.setDeposit(deposit);

        System.out.println();
        System.out.println("-- Student account created. --");
        student.printInfo();
        System.out.println("------------------------------");

        updateStudent(student);
        return student;
    }

    public void modify(){
        boolean finished = false;
        do {
            System.out.println("Updating student " + getID() + "...");
            System.out.println("1 - First Name");
            System.out.println("2 - Last Name");
            System.out.println("3 - Gender");
            System.out.println("4 - Phone Number");
            System.out.println("5 - Address");
            System.out.println("6 - Number of Modules Enrolled");
            System.out.println("7 - Number of Repeat Modules Enrolled");
            System.out.println("8 - Add deposit");
            System.out.println("9 - View info");
            System.out.println("0 - Finish updating");
            int choice = getInt("Enter menu choice: ", 0, 9);
            switch (choice) {
                case 1:
                    updateFirstName(getLine("Enter first name: "));
                    break;
                case 2:
                    updateLastName(getLine("Enter last name: "));
                    break;
                case 3:
                    System.out.println("Genders: ");
                    System.out.println("1 - Male");
                    System.out.println("2 - Female");
                    System.out.println("3 - Unspecified");
                    int choice2 = getInt("Enter gender: ", 3);
                    switch (choice2) {
                        case 1:
                            updateGender(Gender.Male);
                            break;
                        case 2:
                            updateGender(Gender.Female);
                            break;
                        case 3:
                            updateGender(Gender.Unspecified);
                    }
                    break;
                case 4:
                    updatePhoneNumber(getLine("Enter phone number: "));
                    break;
                case 5:
                    updateAddress(getLine("Enter address: "));
                    break;
                case 6:
                    int modules = getInt("Enter new number of modules enrolled: ", 0, 6);
                    if (getNumRepeatModules() > 2 && modules > 0)
                        System.out.println("Student not allowed to take normal modules while taking more than two repeat modules. Not saving.");
                    else if (getNumRepeatModules() + modules > 6)
                        System.out.println("Total modules exceed 6. Not saving.");
                    else updateNumModules(modules);
                    break;
                case 7:
                    int repeatModules = getInt("Enter new number of repeat modules enrolled:");
                    if (repeatModules > 2 && getNumModules() > 0)
                        System.out.println("Student not allowed to take normal modules while taking more than two repeat modules. Not saving.");
                    else if (repeatModules + getNumModules() > 6)
                        System.out.println("Total modules exceed 6. Not saving.");
                    else updateNumRepeatModules(repeatModules);
                    break;
                case 8: addDeposit(getDouble("Enter deposit to add in Php: ")); break;
                case 9: printInfo(); break;
                case 0: finished = true;
            }
        } while (!finished);
        updateStudent(this);
        System.out.println("Done updating.");
        System.out.println();
    }

    public static int getStudentIDInput(){
        int ID = getInt("Enter ID: ");
        while (studentIdExists(ID)){
            System.out.println("Student ID already exists!");
            ID = getInt("Enter ID: ");
        }
        return ID;
    }


    // File operations

    public static void updateStudent(Student student){
        if (student == null){
            System.out.println("Student not in students file.");
            return;
        }
        int ID = student.getID();
        boolean exists = studentIdExists(ID);
        String toWrite = student.toFileEntry();
        if (exists){  // replace entry
            String contents = "";
            try {
                contents = new String(Files.readAllBytes(studentsFile.toPath()));
            } catch (Exception e){
                Dialogs.showErrorDialog("!!! Error in students file reading! Check file permissions.");
            }
            toWrite = contents.replaceAll("(?m)^" + ID + "\\|.*", toWrite);  // replace line of specific student
        }
        try (FileWriter writer = new FileWriter(studentsFile,!exists)){  // append if student does not exist yet
            writer.write(toWrite);
        } catch (Exception e){
            Dialogs.showErrorDialog("!!! Error in students file writing! Check file permissions.");
            System.exit(0);
        }
    }

    public static void deleteStudent(int ID){
        boolean exists = studentIdExists(ID);
        String toWrite = "";
        if (exists){
            String contents = "";
            try {
                contents = new String(Files.readAllBytes(studentsFile.toPath()));
            } catch (Exception e){
                Dialogs.showErrorDialog("!!! Error in students file reading! Check file permissions.");
            }
            toWrite = contents.replaceAll("(?m)^" + ID + "\\|.*?[\r\n]+", "");  // replace line of specific student
        } else {
            Dialogs.showWarningDialog("Student not in students file.");
            return; }
        try (FileWriter writer = new FileWriter(studentsFile,false)){
            writer.write(toWrite);
        } catch (Exception e){
            Dialogs.showErrorDialog("!!! Error in students file writing! Check file permissions.");
            System.exit(0);
        }
    }

    public static Student getStudent(int ID){
        try (BufferedReader reader = new BufferedReader(new FileReader(studentsFile))){
            String line = reader.readLine();
            while (line != null) {
                if (line.trim().split("\\|")[0].equals(ID+"")) return fromFileEntry(line);
                line = reader.readLine();
            }
        } catch (Exception e){
            Dialogs.showErrorDialog("!!! Error in students file reading! Check file permissions.");
            System.exit(0);
        }
        return null;
    }

    public static Student[] filterStudents(boolean thatHasBalance){
        Student[] students = new Student[1000];
        int studentCount = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(studentsFile))){
            String line = reader.readLine();
            while (line != null) {
                if (line.trim().isEmpty()){
                    line = reader.readLine();
                    continue;
                }
                Student student = fromFileEntry(line);
                if (student != null && thatHasBalance == (student.computeRemainingBalance() >= 0.01)){
                    students[studentCount] = student;
                    studentCount++;
                }
                line = reader.readLine();
            }
        } catch (Exception e){
            Dialogs.showErrorDialog("!!! Error in students file reading! Check file permissions.");
            System.exit(0);
        }
        Student[] output = new Student[studentCount];
        System.arraycopy(students,0,output,0,studentCount);
        return output;
    }

    public static boolean studentIdExists(int ID){
        return getStudent(ID) != null;
    }

    public String toFileEntry(){
        return String.format("%s|%s|%s|%s|%s|%s|%s|%s|%s\n",
            getID(), getLastName(), getFirstName(), getGender(), getPhoneNumber(),
            getAddress(), getNumModules(), getNumRepeatModules(), getFeeDeposit());
    }

    public static Student fromFileEntry(String line){
        Student student = null;
        try {
            String[] data = line.trim().split("\\|");
            int ID;
            try {
                ID = Integer.parseInt(data[0].trim());
            } catch (NumberFormatException e){
                System.out.println("WARNING: Entry [ " + line + " ] has invalid ID. Setting it to 0.");
                ID = 0;
            }
            String lastName = data[1];
            String firstName = data[2];
            Gender gender;
            try {
                gender = Gender.valueOf(data[3]);
            } catch (IllegalArgumentException e){
                System.out.println("WARNING: Entry [ " + line + " ] has invalid Gender. Setting it to Unspecified.");
                gender = Gender.Unspecified;
            }
            String phoneNumber = data[4];
            String address = data[5];
            student = new Student(ID, firstName, lastName, gender, phoneNumber, address);

            try { student.updateNumModules(Integer.parseInt(data[6].trim())); }
            catch (NumberFormatException e){
                System.out.print("WARNING: Entry [ " + line + " ] has invalid numModules. Setting it to 0.");
                student.updateNumModules(0);
            }

            try { student.updateNumRepeatModules(Integer.parseInt(data[7].trim())); }
            catch (NumberFormatException e){
                System.out.print("WARNING: Entry [ " + line + " ] has invalid numRepeatModules. Setting it to 0.");
                student.updateNumRepeatModules(0);
            }

            try { student.setDeposit(Double.parseDouble(data[8].trim())); }
            catch (NumberFormatException e){
                System.out.print("WARNING: Entry [ " + line + " ] has invalid amountPaid. Setting it to 0.");
                student.setDeposit(0);
            }
        } catch (ArrayIndexOutOfBoundsException e){
            System.out.println("WARNING: Entry [ " + line + " ] in students is corrupt/lacks information.");
        }
        return student;
    }
}
