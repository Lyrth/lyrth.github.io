import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.text.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

public class Dialogs {
    public static void showErrorDialog(String message){
        showMessageDialog(message, JOptionPane.ERROR_MESSAGE);
    }

    public static void showInfoDialog(String message){
        showMessageDialog(message, JOptionPane.INFORMATION_MESSAGE);
    }

    public static void showWarningDialog(String message){
        showMessageDialog(message, JOptionPane.WARNING_MESSAGE);
    }

    public static String showSingleInputDialog(String message, boolean numberOnly, String def){
        try {
            return (String) new InputsDialog().add(message, numberOnly ? 1 : 0, def).show().get(0);
        } catch (Exception e) {
            return null;
        }
    }

    private static void showMessageDialog(String message, int type){
        String title = "";
        switch (type){
            case JOptionPane.ERROR_MESSAGE:
                title = "Error";
                break;
            case JOptionPane.WARNING_MESSAGE:
                title = "Warning";
                break;
            case JOptionPane.INFORMATION_MESSAGE:
                title = "Info";
                break;
        }
        JOptionPane.showMessageDialog(null, message, title, type);
    }

    // 0 : yes ; 1 : no ; -1 : quit
    public static int showYesNoDialog(String message, boolean warning){
        String title = "Info";
        if (warning) title = "Warning";
        return JOptionPane.showConfirmDialog(null,message,title,
            JOptionPane.YES_NO_OPTION,
            warning ? JOptionPane.WARNING_MESSAGE : JOptionPane.QUESTION_MESSAGE);
    }

    public static void showStudentTableDialog(String msg, Student[] people){
        JOptionPane optionPane = new JOptionPane();
        JDialog dialog = optionPane.createDialog("List");
        dialog.setMinimumSize(new Dimension(600,200));
        optionPane.setLayout(new BoxLayout(optionPane,BoxLayout.Y_AXIS));
        optionPane.setMessage(msg);
        String[][] data = new String[people.length][4];
        int i = 0;
        for (Student p : people){
            data[i] = new String[]{""+p.getID(),p.getName(true),""+p.getFeeDeposit(),""+p.computeRemainingBalance()};
            i++;
        }
        JTable table = new JTable(data, new String[]{"ID","Name","Deposit","Remaining Balance"});
        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(new EmptyBorder(10,10,10,10));
        optionPane.setOptionType(JOptionPane.DEFAULT_OPTION);
        optionPane.add(sp);
        dialog.pack();
        dialog.setVisible(true);
    }

    public static void showTeacherTableDialog(String msg, Teacher[] people){
        JOptionPane optionPane = new JOptionPane();
        JDialog dialog = optionPane.createDialog("List");
        dialog.setMinimumSize(new Dimension(900,200));
        optionPane.setLayout(new BoxLayout(optionPane,BoxLayout.Y_AXIS));
        optionPane.setMessage(msg);
        String[][] data = new String[people.length][5];
        int i = 0;
        for (Teacher p : people){
            data[i] = new String[]{""+p.getID(),p.getName(true),""+p.getNumHours(),""+p.getDepartment(),""+p.getDesignation()};
            i++;
        }
        JTable table = new JTable(data, new String[]{"ID","Name","Teaching Hours","Department","Designation"});
        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(new EmptyBorder(10,10,10,10));
        optionPane.setOptionType(JOptionPane.DEFAULT_OPTION);
        optionPane.add(sp);
        dialog.pack();
        dialog.setVisible(true);
    }

    public static int showButtonsDialog(String title, String message, String message2, String... choices){
        JDialog dialog = new JDialog();
        dialog.setTitle(title);
        Container contentPane = dialog.getContentPane();
        contentPane.setLayout(new BoxLayout(contentPane,BoxLayout.Y_AXIS));
        JPanel labelPanel1 = new JPanel();
        JPanel labelPanel2 = new JPanel();
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel,BoxLayout.Y_AXIS));
        labelPanel1.add(Box.createHorizontalGlue());
        labelPanel1.add(new JLabel("<html>" + message.replace("\n","<br>") + "</html>"));
        labelPanel1.add(Box.createHorizontalGlue());
        labelPanel2.add(Box.createHorizontalGlue());
        labelPanel2.add(new JLabel("<html>" + message2.replace("\n","<br>") + "</html>"));
        labelPanel2.add(Box.createHorizontalGlue());
        JButton[] buttons = new JButton[choices.length];
        AtomicReference<JButton> choice = new AtomicReference<>();
        for (int i = 0; i < choices.length; i++) {
            buttons[i] = new JButton(choices[i]);
            buttons[i].addActionListener(e -> {
                dialog.setVisible(false);
                dialog.dispose();
                choice.set((JButton) e.getSource());
            });
            buttonPanel.add(Box.createVerticalStrut(5));
            JPanel localPanel = new JPanel();
            localPanel.add(Box.createHorizontalGlue());
            localPanel.add(buttons[i]);
            localPanel.add(Box.createHorizontalGlue());
            buttonPanel.add(localPanel);
        }
        //buttonPanel.add(Box.createVerticalStrut(10));
        labelPanel1.setBorder(new EmptyBorder(10,10,10,10));
        buttonPanel.setBorder(new EmptyBorder(0,50,30,50));
        contentPane.add(labelPanel1);
        contentPane.add(labelPanel2);
        contentPane.add(buttonPanel);
        dialog.pack();
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        dialog.setLocation(d.width/2 - dialog.getWidth()/2, d.height/2 - dialog.getHeight()/2);
        dialog.setModal(true);
        dialog.setVisible(true);
        JButton button = choice.get();
        for (int i = 0; i < choices.length; i++) {
            if (buttons[i] == button) return i;
        }
        return -1;
    }

    public static InputsDialog createInputsDialog(){
        return new InputsDialog();
    }

    public static void maino(String[] args) {
        //System.out.println(showYesNoDialog("Baba na ba?",true));
        System.out.println(showButtonsDialog("TEJUCO Colleges","Welcome to TEJUCO Colleges Accounting system!","a","bb","ccc"));
        /*
        showSingleInputDialog("Enter x",false, null);
        new InputsDialog().add("One",0,"default1")
            .add("Two",1,"21")
            .add("Three",1,null)
            .add("Three",1,null)
            .add("Three",1,null)
            .add("Three",1,null)
            .add("Three",1,null)
            .add("Three",1,null)
            .add("Three",1,null)
            .add("Three",1,null)
            .show();

        //JOptionPane.showInputDialog(null, "Test", "Title", 0, null, new String[]{"a","b","c"},"a");
         */
    }
}

class InputsDialog {

    public List<JTextField> fields = new ArrayList<>();
    public JPanel panel = new JPanel();

    public InputsDialog(){
        panel.setBounds(0,0,800,400);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
    }

    public InputsDialog(InputsDialog d){
        super();
        fields = d.fields;
        panel = d.panel;
    }

    // type - 0:Normal , 1:IntOnly , 2:DoubleOnly , 3:Disabled
    public InputsDialog add(String label, int type, String def){
        if (def == null) def = "";
        JPanel localPanel = new JPanel();
        localPanel.setLayout(new BoxLayout(localPanel, BoxLayout.X_AXIS));
        localPanel.add(new JLabel(label));
        localPanel.add(Box.createHorizontalStrut(15));
        JTextField field = new JTextField();
        field.setText(def);
        if (type == 1) ((PlainDocument)field.getDocument()).setDocumentFilter(new IntFilter());
        else if (type == 2) ((PlainDocument)field.getDocument()).setDocumentFilter(new DoubleFilter());
        else if (type == 3) field.setEnabled(false);
        localPanel.add(field);
        fields.add(field);
        panel.add(Box.createVerticalStrut(5));
        panel.add(localPanel);
        return this;
    }

    public ArrayList<Object> show(){
        int response = JOptionPane.showOptionDialog(null, panel,"Input",-1,-1, null,null,null);
        if (response == -1) return null;
        ArrayList<Object> objs = new ArrayList<>();
        fields.forEach(field -> objs.add(field.getText()));
        return objs;
    }

    static class IntFilter extends DocumentFilter {
        public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
            Document doc = fb.getDocument();
            StringBuilder sb = new StringBuilder();
            sb.append(doc.getText(0, doc.getLength()));
            sb.insert(offset, string);
            if (test(sb.toString())) super.insertString(fb, offset, string, attr);
            else super.insertString(fb,offset,sb.toString().replaceAll("[^0-9]",""),attr);
        }

        private boolean test(String text) {
            try {
                if (text.isEmpty()) return true;
                Integer.parseInt(text);
                return true;
            } catch (NumberFormatException e) {
                return false;
            }
        }

        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
            Document doc = fb.getDocument();
            StringBuilder sb = new StringBuilder();
            sb.append(doc.getText(0, doc.getLength()));
            sb.replace(offset, offset + length, text);
            if (test(sb.toString())) super.replace(fb, offset, length, text, attrs);
        }

        public void remove(DocumentFilter.FilterBypass fb, int offset, int length)
            throws BadLocationException {
            Document doc = fb.getDocument();
            StringBuilder sb = new StringBuilder();
            sb.append(doc.getText(0, doc.getLength()));
            sb.delete(offset, offset + length);
            if (test(sb.toString())) super.remove(fb, offset, length);
        }
    }

    static class DoubleFilter extends DocumentFilter {
        public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
            Document doc = fb.getDocument();
            StringBuilder sb = new StringBuilder();
            sb.append(doc.getText(0, doc.getLength()));
            sb.insert(offset, string);
            if (test(sb.toString())) super.insertString(fb, offset, string, attr);
            else super.insertString(fb,offset,sb.toString().replaceAll("[^0-9]",""),attr);
        }

        private boolean test(String text) {
            try {
                if (text.isEmpty()) return true;
                Double.parseDouble(text);
                return true;
            } catch (NumberFormatException e) {
                return false;
            }
        }

        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
            Document doc = fb.getDocument();
            StringBuilder sb = new StringBuilder();
            sb.append(doc.getText(0, doc.getLength()));
            sb.replace(offset, offset + length, text);
            if (test(sb.toString())) super.replace(fb, offset, length, text, attrs);
        }

        public void remove(DocumentFilter.FilterBypass fb, int offset, int length)
            throws BadLocationException {
            Document doc = fb.getDocument();
            StringBuilder sb = new StringBuilder();
            sb.append(doc.getText(0, doc.getLength()));
            sb.delete(offset, offset + length);
            if (test(sb.toString())) super.remove(fb, offset, length);
        }
    }
}
