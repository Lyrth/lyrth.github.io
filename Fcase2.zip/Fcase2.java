import java.nio.file.Files;
import java.util.ArrayList;

public class Fcase2 {
    public static void main(String[] args) {
        // create files
        prepareFiles();
        do {
            int choice = Dialogs.showButtonsDialog(
                "TEJUCO Colleges",
                "Welcome to TEJUCO Colleges Accounting system!",
                    "Please select account type.",
                "Students", "Teachers", "Exit");
            switch (choice) {
                case 0:  // Students
                    studentOps();
                    break;
                case 1:  // Teachers
                    teacherOps();
                    break;
                case -1:
                case 2:  // Exit
                    if (Dialogs.showYesNoDialog("Do you want to exit?", true) == 0)
                        System.exit(0);
            }
        } while (true);
    }

    public static void studentOps(){
        do {
            int choice = Dialogs.showButtonsDialog(
                "TEJUCO Colleges",
                "Welcome to TEJUCO Colleges Accounting system!",
                "Please select student account operation.",
                "Add new student", "Update student", "Delete student", "Show student balance",
                "Add student deposit", "Display students without pending balance", "Display students with pending balance", "Back");
            st:
            switch (choice) {
                case 0:  // Add
                    InputsDialog dialog = Dialogs.createInputsDialog()
                        .add("ID",1,"201800000")        // 0
                        .add("First Name", 0, "")       // 1
                        .add("Last Name", 0, "")        // 2
                        .add("Gender", 0, "M")          // 3
                        .add("Phone Number", 0, "+639") // 4
                        .add("Address", 0, "")          // 5
                        .add("Number of Modules Enrolled", 1,"6")   // 6
                        .add("Number of Repeat Modules", 1, "0")    // 7
                        .add("Initial Deposit Amount", 2, "0.0");   // 8
                    boolean ok = false;
                    ArrayList<Object> data;
                    do {
                        data = dialog.show();
                        if (data == null) break st;
                        if (((String)data.get(0)).length() == 0 || (((String)data.get(0)).isEmpty())){
                            Dialogs.showErrorDialog("ID cannot be blank.");
                        } else if (Student.studentIdExists(Integer.parseInt((String)data.get(0)))){
                            Dialogs.showErrorDialog("This ID already exists!");
                        } else if (((String)data.get(1)).length() == 0 || (((String)data.get(1)).isEmpty())){
                            Dialogs.showErrorDialog("First name cannot be blank.");
                        } else if (((String)data.get(2)).length() == 0 || (((String)data.get(2)).isEmpty())){
                            Dialogs.showErrorDialog("Last name cannot be blank.");
                        } else if (!((String)data.get(3)).toLowerCase().matches("m(ale)?|f(emale)?|u(nsp(ec(ified)?)?)?")){
                            Dialogs.showErrorDialog("Invalid gender! Accepted formats: (M)ale, (F)emale, (U)nspecified.");
                        } else if (Integer.parseInt((String)data.get(6))+Integer.parseInt((String)data.get(7)) > 6){
                            Dialogs.showErrorDialog("Only a combined maximum of 6 modules can be taken at a time.");
                        } else if (Integer.parseInt((String)data.get(7)) > 2 && Integer.parseInt((String)data.get(6)) > 0){
                            Dialogs.showErrorDialog("Can only take two repeat modules when taking up normal modules!");
                        } else {
                            ok = true;
                        }
                    } while (!ok);
                    Gender gender;
                    if (((String)data.get(3)).toLowerCase().matches("m(ale)?")){
                        gender = Gender.Male;
                    } else if (((String)data.get(3)).toLowerCase().matches("f(emale)?")){
                        gender = Gender.Female;
                    } else {
                        gender = Gender.Unspecified;
                    }
                    Student student = new Student(
                        Integer.parseInt((String)data.get(0)),
                        (String)data.get(1),
                        (String)data.get(2),
                        gender,
                        (String)data.get(4),
                        (String)data.get(5));
                    student.updateNumModules(Integer.parseInt((String)data.get(6)));
                    student.updateNumRepeatModules(Integer.parseInt((String)data.get(7)));
                    student.setDeposit(Double.parseDouble((String)data.get(8)));
                    Student.updateStudent(student);
                    Dialogs.showButtonsDialog(
                        "Account created!",
                        "Student account created!",
                        student.info(),
                        "Back");
                    break;
                case 1:  // Update
                    String strid = Dialogs.showSingleInputDialog("Enter ID:",true,"");
                    if (strid == null || strid.isEmpty()) break;
                    int ID = Integer.parseInt(strid);
                    student = Student.getStudent(ID);
                    if (student == null){
                        Dialogs.showErrorDialog("Student doesn't exist.");
                        break;
                    }
                    InputsDialog dialog2 = Dialogs.createInputsDialog()
                        .add("ID",3,""+ID)        // 0
                        .add("First Name", 0, student.getFirstName())       // 1
                        .add("Last Name", 0, student.getLastName())        // 2
                        .add("Gender", 0, student.getGender().name())          // 3
                        .add("Phone Number", 0, student.getPhoneNumber()) // 4
                        .add("Address", 0, student.getAddress())          // 5
                        .add("Number of Modules Enrolled", 1,""+student.getNumModules())   // 6
                        .add("Number of Repeat Modules", 1, ""+student.getNumRepeatModules())    // 7
                        .add("Initial Deposit Amount", 2, ""+student.getFeeDeposit());   // 8
                    boolean ok2 = false;
                    do {
                        data = dialog2.show();
                        if (data == null) break st;
                        if (((String)data.get(1)).length() == 0 || (((String)data.get(1)).isEmpty())){
                            Dialogs.showWarningDialog("First name cannot be blank.");
                        } else if (((String)data.get(2)).length() == 0 || (((String)data.get(2)).isEmpty())){
                            Dialogs.showWarningDialog("Last name cannot be blank.");
                        } else if (!((String)data.get(3)).toLowerCase().matches("m(ale)?|f(emale)?|u(nsp(ec(ified)?)?)?")){
                            Dialogs.showWarningDialog("Invalid gender! Accepted formats: (M)ale, (F)emale, (U)nspecified.");
                        } else if (Integer.parseInt((String)data.get(6))+Integer.parseInt((String)data.get(7)) > 6){
                            Dialogs.showWarningDialog("Only a combined maximum of 6 modules can be taken at a time.");
                        } else if (Integer.parseInt((String)data.get(7)) > 2 && Integer.parseInt((String)data.get(6)) > 0){
                            Dialogs.showWarningDialog("Can only take two repeat modules when taking up normal modules!");
                        } else {
                            ok2 = true;
                        }
                    } while (!ok2);
                    if (((String)data.get(3)).toLowerCase().matches("m(ale)?")){
                        gender = Gender.Male;
                    } else if (((String)data.get(3)).toLowerCase().matches("f(emale)?")){
                        gender = Gender.Female;
                    } else {
                        gender = Gender.Unspecified;
                    }
                    student = new Student(
                        Integer.parseInt((String)data.get(0)),
                        (String)data.get(1),
                        (String)data.get(2),
                        gender,
                        (String)data.get(4),
                        (String)data.get(5));
                    student.updateNumModules(Integer.parseInt((String)data.get(6)));
                    student.updateNumRepeatModules(Integer.parseInt((String)data.get(7)));
                    student.setDeposit(Double.parseDouble((String)data.get(8)));
                    Student.updateStudent(student);
                    Dialogs.showButtonsDialog(
                        "Account updated!",
                        "Student account updated!",
                        student.info(),
                        "Back");
                    break;
                case 2:  // Delete
                    strid = Dialogs.showSingleInputDialog("Enter ID:",true,"");
                    if (strid == null || strid.isEmpty()) break;
                    ID = Integer.parseInt(strid);
                    student = Student.getStudent(ID);
                    if (student == null){
                        Dialogs.showErrorDialog("Student doesn't exist.");
                        break;
                    }
                    if (Dialogs.showYesNoDialog(
                        String.format("Are you sure you want to delete %s? (%s)",
                            ID,student.getName(true)),true) == 0){
                        Student.deleteStudent(ID);
                        Dialogs.showInfoDialog("" + ID + " Deleted.");
                    }
                    break;
                case 3:  // Showbal
                    strid = Dialogs.showSingleInputDialog("Enter ID:",true,"");
                    if (strid == null || strid.isEmpty()) break;
                    ID = Integer.parseInt(strid);
                    student = Student.getStudent(ID);
                    if (student == null){
                        Dialogs.showErrorDialog("Student doesn't exist.");
                        break;
                    }
                    Dialogs.showButtonsDialog(
                        "Balance Check",
                        student.getName(true) + "'s current balance:",
                        student.balanceInfo(),
                        "Back");
                    break;
                case 4:  // Adddep
                    strid = Dialogs.showSingleInputDialog("Enter ID:",true,"");
                    if (strid == null || strid.isEmpty()) break;
                    ID = Integer.parseInt(strid);
                    student = Student.getStudent(ID);
                    if (student == null){
                        Dialogs.showErrorDialog("Student doesn't exist.");
                        break;
                    }
                    ArrayList<Object> inp = Dialogs.createInputsDialog()
                        .add("Enter amount to add:",2,"0.0").show();
                    if (inp == null) break;
                    if (inp.get(0) == null || ((String)inp.get(0)).isEmpty()){
                        Dialogs.showInfoDialog("Nothing to add.");
                        break;
                    } else {
                        student.addDeposit(Double.parseDouble((String)inp.get(0)));
                        Student.updateStudent(student);
                    }
                    Dialogs.showButtonsDialog(
                        "Add Deposit",
                        student.getName(true) + "'s current balance was updated:",
                        student.balanceInfo(),
                        "Back");
                    break;
                case 5:  // Withoutbal
                    Dialogs.showStudentTableDialog("Students without pending balance:",Student.filterStudents(false));
                    break;
                case 6:  // Withbal
                    Dialogs.showStudentTableDialog("Students with pending balance:",Student.filterStudents(true));
                    break;
                case -1:
                case 7:
                    return;
            }
        } while (true);
    }

    public static void teacherOps(){
        do {
            int choice = Dialogs.showButtonsDialog(
                "TEJUCO Colleges",
                "Welcome to TEJUCO Colleges Accounting system!",
                "Please select teacher account operation.",
                "Add new teacher", "Update teacher", "Delete teacher", "Calculate teacher salary", "Show all teachers", "Back");
            st:
            switch (choice) {
                case 0:  // Add
                    InputsDialog dialog = Dialogs.createInputsDialog()
                        .add("ID",1,"301800000")        // 0
                        .add("First Name", 0, "")       // 1
                        .add("Last Name", 0, "")        // 2
                        .add("Gender", 0, "M")          // 3
                        .add("Phone Number", 0, "+639") // 4
                        .add("Address", 0, "")          // 5
                        .add("Number of Teaching Hours", 1,"0")   // 6
                        .add("Department", 0, "BS")    // 7
                        .add("Designation", 0, "L");   // 8
                    boolean ok = false;
                    ArrayList<Object> data;
                    do {
                        data = dialog.show();
                        if (data == null) break st;
                        if (((String)data.get(0)).length() == 0 || (((String)data.get(0)).isEmpty())){
                            Dialogs.showErrorDialog("ID cannot be blank.");
                        } else if (Student.studentIdExists(Integer.parseInt((String)data.get(0)))){
                            Dialogs.showErrorDialog("This ID already exists!");
                        } else if (((String)data.get(1)).length() == 0 || (((String)data.get(1)).isEmpty())){
                            Dialogs.showErrorDialog("First name cannot be blank.");
                        } else if (((String)data.get(2)).length() == 0 || (((String)data.get(2)).isEmpty())){
                            Dialogs.showErrorDialog("Last name cannot be blank.");
                        } else if (!((String)data.get(3)).toLowerCase().matches("m(ale)?|f(emale)?|u(nsp(ec(ified)?)?)?")){
                            Dialogs.showErrorDialog("Invalid gender! Accepted formats: (M)ale, (F)emale, (U)nspecified.");
                        } else if (!((String)data.get(7)).toLowerCase().matches("bs|b(usiness)?|c(o(mputing)?)?")){
                            Dialogs.showErrorDialog("Invalid department! Accepted formats: BS/(B)usiness, CO/(C)omputing");
                        } else if (!((String)data.get(8)).toLowerCase().matches("hof|h(ead( of faculty)?)?|c(o(ord(inator)?)?)?|l(ec(turer)?)?")){
                            Dialogs.showErrorDialog("Invalid designation! Accepted formats: HOF/(H)ead of Faculty, CO/(C)oordinator, LEC/(L)ecturer");
                        } else {
                            ok = true;
                        }
                    } while (!ok);
                    Gender gender;
                    if (((String)data.get(3)).toLowerCase().matches("m(ale)?")){
                        gender = Gender.Male;
                    } else if (((String)data.get(3)).toLowerCase().matches("f(emale)?")){
                        gender = Gender.Female;
                    } else {
                        gender = Gender.Unspecified;
                    }
                    TeacherDepartment department;
                    if (((String)data.get(7)).toLowerCase().matches("bs|b(usiness)?")){
                        department = TeacherDepartment.Business;
                    } else {
                        department = TeacherDepartment.Computing;
                    }
                    TeacherDesignation designation;
                    if (((String)data.get(8)).toLowerCase().matches("l(ec(turer)?)?")){
                        designation = TeacherDesignation.L;
                    } else if (((String)data.get(3)).toLowerCase().matches("c(o(ord(inator)?)?)?")){
                        designation = TeacherDesignation.CO;
                    } else {
                        designation = TeacherDesignation.HOF;
                    }
                    Teacher teacher = new Teacher(
                        Integer.parseInt((String)data.get(0)),
                        (String)data.get(1),
                        (String)data.get(2),
                        gender,
                        (String)data.get(4),
                        (String)data.get(5));
                    teacher.updateNumHours(Integer.parseInt((String)data.get(6)));
                    teacher.updateDesignation(designation);
                    teacher.updateDepartment(department);
                    Teacher.updateTeacher(teacher);
                    Dialogs.showButtonsDialog(
                        "Account created!",
                        "Teacher account created!",
                        teacher.info(),
                        "Back");
                    break;
                case 1:  // Update
                    String strid = Dialogs.showSingleInputDialog("Enter teacher ID:",true,"");
                    if (strid == null || strid.isEmpty()) break;
                    int ID = Integer.parseInt(strid);
                    teacher = Teacher.getTeacher(ID);
                    if (teacher == null){
                        Dialogs.showErrorDialog("Teacher doesn't exist.");
                        break;
                    }
                    InputsDialog dialog2 = Dialogs.createInputsDialog()
                        .add("ID",3,""+ID)        // 0
                        .add("First Name", 0, teacher.getFirstName())       // 1
                        .add("Last Name", 0, teacher.getLastName())        // 2
                        .add("Gender", 0, teacher.getGender().name())          // 3
                        .add("Phone Number", 0, teacher.getPhoneNumber()) // 4
                        .add("Address", 0, teacher.getAddress())          // 5
                        .add("Number of Teaching Hours", 1,""+teacher.getNumHours())   // 6
                        .add("Department", 0, teacher.getDepartment().name())    // 7
                        .add("Designation", 0, teacher.getDesignation().name());   // 8  // 8
                    boolean ok2 = false;
                    do {
                        data = dialog2.show();
                        if (data == null) break st;
                        if (((String)data.get(1)).length() == 0 || (((String)data.get(1)).isEmpty())){
                            Dialogs.showWarningDialog("First name cannot be blank.");
                        } else if (((String)data.get(2)).length() == 0 || (((String)data.get(2)).isEmpty())){
                            Dialogs.showWarningDialog("Last name cannot be blank.");
                        } else if (!((String)data.get(3)).toLowerCase().matches("m(ale)?|f(emale)?|u(nsp(ec(ified)?)?)?")){
                            Dialogs.showWarningDialog("Invalid gender! Accepted formats: (M)ale, (F)emale, (U)nspecified.");
                        } else if (!((String)data.get(7)).toLowerCase().matches("bs|b(usiness)?|c(o(mputing)?)?")){
                            Dialogs.showErrorDialog("Invalid department! Accepted formats: BS/(B)usiness, CO/(C)omputing");
                        } else if (!((String)data.get(8)).toLowerCase().matches("hof|h(ead( of faculty)?)?|c(o(ord(inator)?)?)?|l(ec(turer)?)?")){
                            Dialogs.showErrorDialog("Invalid designation! Accepted formats: HOF/(H)ead of Faculty, CO/(C)oordinator, LEC/(L)ecturer");
                        } else {
                            ok = true;
                        }
                    } while (!ok2);
                    if (((String)data.get(3)).toLowerCase().matches("m(ale)?")){
                        gender = Gender.Male;
                    } else if (((String)data.get(3)).toLowerCase().matches("f(emale)?")){
                        gender = Gender.Female;
                    } else {
                        gender = Gender.Unspecified;
                    }
                    if (((String)data.get(7)).toLowerCase().matches("bs|b(usiness)?")){
                        department = TeacherDepartment.Business;
                    } else {
                        department = TeacherDepartment.Computing;
                    }
                    if (((String)data.get(8)).toLowerCase().matches("l(ec(turer)?)?")){
                        designation = TeacherDesignation.L;
                    } else if (((String)data.get(3)).toLowerCase().matches("c(o(ord(inator)?)?)?")){
                        designation = TeacherDesignation.CO;
                    } else {
                        designation = TeacherDesignation.HOF;
                    }
                    teacher = new Teacher(
                        Integer.parseInt((String)data.get(0)),
                        (String)data.get(1),
                        (String)data.get(2),
                        gender,
                        (String)data.get(4),
                        (String)data.get(5));
                    teacher.updateNumHours(Integer.parseInt((String)data.get(6)));
                    teacher.updateDesignation(designation);
                    teacher.updateDepartment(department);
                    Teacher.updateTeacher(teacher);
                    Dialogs.showButtonsDialog(
                        "Account updated!",
                        "Teacher account updated!",
                        teacher.info(),
                        "Back");
                    break;
                case 2:  // Delete
                    strid = Dialogs.showSingleInputDialog("Enter Teacher ID:",true,"");
                    if (strid == null || strid.isEmpty()) break;
                    ID = Integer.parseInt(strid);
                    teacher = Teacher.getTeacher(ID);
                    if (teacher == null){
                        Dialogs.showErrorDialog("Teacher doesn't exist.");
                        break;
                    }
                    if (Dialogs.showYesNoDialog(
                        String.format("Are you sure you want to delete %s? (%s)",
                            ID,teacher.getName(true)),true) == 0){
                        Teacher.deleteTeacher(ID);
                        Dialogs.showInfoDialog("" + ID + " Deleted.");
                    }
                    break;
                case 3:  // Salary
                    strid = Dialogs.showSingleInputDialog("Enter Teacher ID:",true,"");
                    if (strid == null || strid.isEmpty()) break;
                    ID = Integer.parseInt(strid);
                    teacher = Teacher.getTeacher(ID);
                    if (teacher == null){
                        Dialogs.showErrorDialog("Teacher doesn't exist.");
                        break;
                    }
                    Dialogs.showButtonsDialog(
                        "Balance Check",
                        teacher.getName(true) + "'s salary info:",
                        teacher.salaryInfo(),
                        "Back");
                    break;
                case 4:  // AllTeachers
                    Dialogs.showTeacherTableDialog("List of Teachers",Teacher.getTeachers());
                    break;
                case -1:
                case 5:
                    return;
            }
        } while (true);
    }

    public static void prepareFiles(){
        try {
            Files.createFile(Teacher.teachersFile.toPath());
        } catch (Exception e) {
            if (e.toString().contains("FileAlreadyExists"));  // do nothing
            else {
                System.out.println("!!! Cannot create files! Check program file permissions. Exiting.");
                e.printStackTrace();
                System.exit(0);
            }
        }
        try {
            Files.createFile(Student.studentsFile.toPath());
        } catch (Exception e) {
            if (e.toString().contains("FileAlreadyExists"));  // do nothing
            else {
                System.out.println("!!! Cannot create files! Check program file permissions. Exiting.");
                e.printStackTrace();
                System.exit(0);
            }
        }
    }
}

enum Gender {Unspecified, Male, Female}
enum TeacherDepartment {Business, Computing}
enum TeacherDesignation {
    HOF(8), CO(13), L(18);

    public int normalHours = 0;
    TeacherDesignation(int hours){
        this.normalHours = hours;
    }
}

