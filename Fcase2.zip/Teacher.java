import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.file.Files;

public class Teacher extends Person {

    private TeacherDepartment department = TeacherDepartment.Business;  // default
    private TeacherDesignation designation = TeacherDesignation.L;  // default
    private int numHours;

    static File teachersFile = new File("teachers.txt");

    public Teacher(int ID, String firstName, String lastName, Gender gender, String phoneNumber, String address){
        super(ID, firstName, lastName, gender, phoneNumber, address);
    }

    public static Teacher createAccount(int ID, String firstName, String lastName, Gender gender, String phoneNumber, String address){
        return new Teacher(ID, firstName, lastName, gender, phoneNumber, address);
    }

    public TeacherDepartment getDepartment() {
        return department;
    }

    public void updateDepartment(TeacherDepartment department) {
        this.department = department;
    }

    public TeacherDesignation getDesignation() {
        return designation;
    }

    public void updateDesignation(TeacherDesignation designation) {
        this.designation = designation;
    }

    public int getNumHours() {
        return numHours;
    }

    public void updateNumHours(int numHours) {
        this.numHours = numHours;
    }

    // Calculations

    public double getBaseSalary() {
        return 1200.00;
    }

    public double computeTotalSalary() {
        if (numHours > designation.normalHours)
            return getBaseSalary() + ((numHours - designation.normalHours) * 325);
        else return getBaseSalary();
    }

    public double computeHA() {
        return computeTotalSalary() * 0.10;
    }

    public double computeMA() {
        return computeTotalSalary() * 0.03;
    }

    public double computeTA() {
        return computeTotalSalary() * 0.05;
    }

    public double computeNetSalary() {
        return computeTotalSalary() + computeHA() + computeMA() + computeTA();
    }


    // Print/Format operations

    public String info(){
        return String.format(
            "ID: %s \n" +
                "Role: Teacher\n" +
                "Name: %s\n" +
                "Gender: %s\n" +
                "Phone Number: %s\n" +
                "Address: %s\n" +
                "Department: %s\n" +
                "Designation: %s\n" +
                "Number of hours teaching: %d\n",
            getID(), getName(true), getGender(), getPhoneNumber(),
            getAddress(), getDepartment(), getDesignation(), getNumHours()
        );
    }

    public String salaryInfo(){
        return String.format(
            "Total Salary: Php %.2f\n" +
                "Housing Allowance: Php %.2f\n" +
                "Medical Allowance: Php %.2f\n" +
                "Travelling Allowance: Php %.2f\n" +
                "Net Salary: Php %.2f\n",
            computeTotalSalary(), computeHA(), computeMA(), computeTA(), computeNetSalary()
        );
    }

    public void printInfo(){
        System.out.print(info());
    }


    // Input operations

    public static Teacher createFromInput(){
        int ID, numHours;
        String firstName, lastName, phoneNumber, address;
        Gender gender;
        TeacherDepartment department;
        TeacherDesignation designation;
        ID = getTeacherIDInput();
        firstName = getLine("Enter first name: ");
        lastName = getLine("Enter last name: ");
        System.out.println("Genders: ");
        System.out.println("1 - Male");
        System.out.println("2 - Female");
        System.out.println("3 - Unspecified");
        int choice = getInt("Enter gender: ", 3);
        switch (choice){
            case 1:
                gender = Gender.Male;
                break;
            case 2:
                gender = Gender.Female;
                break;
            default:
                gender = Gender.Unspecified;
        }
        phoneNumber = getLine("Enter phone number: ");
        address = getLine("Enter address: ");

        numHours = getInt("Enter number of teaching hours <default 0>: ");
        Teacher teacher = new Teacher(ID,firstName,lastName,gender,phoneNumber,address);

        System.out.println("Departments: ");
        System.out.println("1 - Business");
        System.out.println("2 - Computing");
        choice = getInt("Enter department: ", 2);
        if (choice == 1)
            department = TeacherDepartment.Business;
        else
            department = TeacherDepartment.Computing;
        System.out.println("Designation: ");
        System.out.println("1 - Head of Faculty");
        System.out.println("2 - Coordinator");
        System.out.println("3 - Lecturer");
        choice = getInt("Enter designation: ", 3);
        switch (choice){
            case 1:
                designation = TeacherDesignation.HOF;
                break;
            case 2:
                designation = TeacherDesignation.CO;
                break;
            default:
                designation = TeacherDesignation.L;
        }
        teacher.updateNumHours(numHours);
        teacher.updateDesignation(designation);
        teacher.updateDepartment(department);

        System.out.println();
        System.out.println("-- Teacher account created. --");
        teacher.printInfo();
        System.out.println("------------------------------");

        updateTeacher(teacher);

        return teacher;
    }

    public void modify(){
        boolean finished = false;
        do {
            System.out.println("Updating teacher " + getID() + "...");
            System.out.println("1 - First Name");
            System.out.println("2 - Last Name");
            System.out.println("3 - Gender");
            System.out.println("4 - Phone Number");
            System.out.println("5 - Address");
            System.out.println("6 - Department");
            System.out.println("7 - Designation");
            System.out.println("8 - Number of Hours Teaching");
            System.out.println("9 - View info");
            System.out.println("0 - Finish updating");
            int choice = getInt("Enter menu choice: ", 0, 9);
            switch (choice) {
                case 1:
                    updateFirstName(getLine("Enter first name: "));
                    break;
                case 2:
                    updateLastName(getLine("Enter last name: "));
                    break;
                case 3:
                    System.out.println("Genders: ");
                    System.out.println("1 - Male");
                    System.out.println("2 - Female");
                    System.out.println("3 - Unspecified");
                    int choice2 = getInt("Enter gender: ", 3);
                    switch (choice2) {
                        case 1:
                            updateGender(Gender.Male);
                            break;
                        case 2:
                            updateGender(Gender.Female);
                            break;
                        case 3:
                            updateGender(Gender.Unspecified);
                    }
                    break;
                case 4:
                    updatePhoneNumber(getLine("Enter phone number: "));
                    break;
                case 5:
                    updateAddress(getLine("Enter address: "));
                    break;
                case 6:
                    System.out.println("Departments: ");
                    System.out.println("1 - Business");
                    System.out.println("2 - Computing");
                    int choice3 = getInt("Enter department: ", 2);
                    if (choice3 == 1)
                        updateDepartment(TeacherDepartment.Business);
                    else
                        updateDepartment(TeacherDepartment.Computing);
                    break;
                case 7:
                    System.out.println("Designation: ");
                    System.out.println("1 - Head of Faculty");
                    System.out.println("2 - Coordinator");
                    System.out.println("3 - Lecturer");
                    int choice4 = getInt("Enter designation: ", 3);
                    switch (choice4){
                        case 1:
                            updateDesignation(TeacherDesignation.HOF);
                            break;
                        case 2:
                            updateDesignation(TeacherDesignation.CO);
                            break;
                        default:
                            updateDesignation(TeacherDesignation.L);
                    }
                    break;
                case 8: updateNumHours(getInt("Enter new number of teaching hours: ")); break;
                case 9: printInfo(); break;
                case 0: finished = true;
            }
        } while (!finished);
        updateTeacher(this);
        System.out.println("Done updating.");
        System.out.println();
    }

    public static int getTeacherIDInput(){
        int ID = getInt("Enter ID: ");
        while (teacherIdExists(ID)){
            System.out.println("Teacher ID already exists!");
            ID = getInt("Enter ID: ");
        }
        return ID;
    }


    // File operations

    public static void updateTeacher(Teacher teacher){
        if (teacher == null){
            System.out.println("Teacher not in teachers file.");
            return;
        }
        int ID = teacher.getID();
        boolean exists = teacherIdExists(ID);
        String toWrite = teacher.toFileEntry();
        if (exists){  // replace entry
            String contents = "";
            try {
                contents = new String(Files.readAllBytes(teachersFile.toPath()));
            } catch (Exception e){
                System.out.println("!!! Error in teachers file reading! Check file permissions.");
            }
            toWrite = contents.replaceAll("(?m)^" + ID + "\\|.*", toWrite);  // replace line of specific teacher
        }
        try (FileWriter writer = new FileWriter(teachersFile,!exists)){  // append if teacher does not exist yet
            writer.write(toWrite);
        } catch (Exception e){
            System.out.println("!!! Error in teachers file writing! Check file permissions.");
            System.exit(0);
        }
    }

    public static void deleteTeacher(int ID){
        boolean exists = teacherIdExists(ID);
        String toWrite = "";
        if (exists){
            String contents = "";
            try {
                contents = new String(Files.readAllBytes(teachersFile.toPath()));
            } catch (Exception e){
                System.out.println("!!! Error in students file reading! Check file permissions.");
            }
            toWrite = contents.replaceAll("(?m)^" + ID + "\\|.*?[\r\n]+", "");  // replace line of specific student
        } else {
            System.out.println("Teacher not in teachers file.");
            return;
        }
        try (FileWriter writer = new FileWriter(teachersFile,false)){
            writer.write(toWrite);
        } catch (Exception e){
            System.out.println("!!! Error in students file writing! Check file permissions.");
            System.exit(0);
        }
    }


    public static Teacher getTeacher(int ID){
        try (BufferedReader reader = new BufferedReader(new FileReader(teachersFile))){
            String line = reader.readLine();
            while (line != null) {
                if (line.trim().split("\\|")[0].equals(ID+"")) return fromFileEntry(line);
                line = reader.readLine();
            }
        } catch (Exception e){
            System.out.println("!!! Error in teachers file reading! Check file permissions.");
            System.exit(0);
        }
        return null;
    }

    public static Teacher[] getTeachers(){
        Teacher[] teachers = new Teacher[1000];
        int teacherCount = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(teachersFile))){
            String line = reader.readLine();
            while (line != null) {
                if (line.trim().isEmpty()){
                    line = reader.readLine();
                    continue;
                }
                if (fromFileEntry(line) != null) {
                    teachers[teacherCount] = fromFileEntry(line);
                    teacherCount++;
                }
                line = reader.readLine();
            }
        } catch (Exception e){
            System.out.println("!!! Error in students file reading! Check file permissions.");
            System.exit(0);
        }
        Teacher[] output = new Teacher[teacherCount];
        System.arraycopy(teachers,0,output,0,teacherCount);
        return output;
    }

    public static boolean teacherIdExists(int ID){
        return getTeacher(ID) != null;
    }

    public String toFileEntry(){
        return String.format("%s|%s|%s|%s|%s|%s|%s|%s|%s\n",
            getID(), getLastName(), getFirstName(), getGender(), getPhoneNumber(),
            getAddress(), getDepartment(), getDesignation(), getNumHours());
    }

    public static Teacher fromFileEntry(String line){
        Teacher teacher = null;
        try {
            String[] data = line.trim().split("\\|");
            int ID;
            try {
                ID = Integer.parseInt(data[0].trim());
            } catch (NumberFormatException e){
                System.out.println("WARNING: Entry [ " + line + " ] has invalid ID. Setting it to 0.");
                ID = 0;
            }
            String lastName = data[1];
            String firstName = data[2];
            Gender gender;
            try {
                gender = Gender.valueOf(data[3]);
            } catch (IllegalArgumentException e){
                System.out.println("WARNING: Entry [ " + line + " ] has invalid Gender. Setting it to Unspecified.");
                gender = Gender.Unspecified;
            }
            String phoneNumber = data[4];
            String address = data[5];
            teacher = new Teacher(ID, firstName, lastName, gender, phoneNumber, address);

            TeacherDepartment department;
            try {
                department = TeacherDepartment.valueOf(data[6]);
            } catch (IllegalArgumentException e){
                System.out.println("WARNING: Entry [ " + line + " ] has invalid Department. Setting it to Business.");
                department = TeacherDepartment.Business;
            }
            TeacherDesignation designation;
            try {
                designation = TeacherDesignation.valueOf(data[7]);
            } catch (IllegalArgumentException e){
                System.out.println("WARNING: Entry [ " + line + " ] has invalid Gender. Setting it to Lecturer.");
                designation = TeacherDesignation.L;
            }
            teacher.updateDepartment(department);
            teacher.updateDesignation(designation);

            try { teacher.updateNumHours(Integer.parseInt(data[8].trim())); }
            catch (NumberFormatException e){
                System.out.print("WARNING: Entry [ " + line + " ] has invalid numHours. Setting it to 0.");
                teacher.updateNumHours(0);
            }
        } catch (ArrayIndexOutOfBoundsException e){
            System.out.println("WARNING: Entry [ " + line + " ] in teachers is corrupt/lacks information.");
        }
        return teacher;
    }
}
