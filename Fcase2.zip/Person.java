import java.util.Scanner;

public class Person {
    private int ID;
    private String firstName;
    private String lastName;
    private Gender gender;
    private String phoneNumber;
    private String address;

    static Scanner in = new Scanner(System.in);

    public Person(){
        this.ID = 0;
        this.firstName = "";
        this.lastName = "";
        this.gender = Gender.Unspecified;
        this.phoneNumber = "";
        this.address = "";
    }

    public Person(int ID, String firstName, String lastName, Gender gender, String phoneNumber, String address){
        this.ID = ID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.phoneNumber = phoneNumber;
        this.address = address;
    }

    public int getID() {
        return ID;
    }

    public void updateID(int ID) {
        this.ID = ID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void updateFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getName(boolean lastNameFirst) {
        if (lastNameFirst) return getLastName() + ", " + getFirstName();
        else return getFirstName() + " " + getLastName();
    }

    public void updateLastName(String lastName) {
        this.lastName = lastName;
    }

    public Gender getGender() {
        return gender;
    }

    public void updateGender(Gender gender) {
        this.gender = gender;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void updatePhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public void updateAddress(String address) {
        this.address = address;
    }


    // Input

    public static String getLine(String prompt){
        System.out.println(prompt);
        System.out.print(">>> ");
        return in.nextLine().trim();
    }

    public static int getInt(String prompt){
        return getInt(prompt,Integer.MIN_VALUE,Integer.MAX_VALUE);
    }

    public static int getInt(String prompt, int max){
        return getInt(prompt, 1,max);
    }

    public static int getInt(String prompt, int min, int max){
        System.out.println(prompt);
        System.out.print(">>> ");
        int input;
        while(true) try {                                       //// Input until valid
            input = Integer.parseInt(in.nextLine().trim());
            if (input < min || input > max) throw new IllegalArgumentException();
            break;
        } catch (NumberFormatException e) {
            System.out.print("[ Invalid input! Not an Integer. ]\n>>> ");
        } catch (IllegalArgumentException e){
            System.out.print("[ That number is not within range! ]\n>>> ");
        }
        return input;
    }

    public static double getDouble(String prompt){
        System.out.println(prompt);
        System.out.print(">>> ");
        double input;
        while(true) try {                                       //// Input until valid
            input = Double.parseDouble(in.nextLine().trim());
            break;
        } catch (NumberFormatException e) {
            System.out.print("[ Invalid input! Not an Integer. ]\n>>> ");
        }
        return input;
    }

}
